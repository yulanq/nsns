﻿namespace Web.Controllers.Notification
{
    public class CourseNotificationController
    {
    }
}
