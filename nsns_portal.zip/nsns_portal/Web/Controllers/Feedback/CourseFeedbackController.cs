﻿namespace Web.Controllers.Feedback
{
    public class CourseFeedbackController
    {
    }
}
