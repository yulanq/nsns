﻿namespace Web.Controllers.Feedback
{
    public class ActivityFeedbackController
    {
    }
}
